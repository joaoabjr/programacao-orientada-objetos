public interface Imposto {
    public double getImpostoPago();
}
